#include "Packet.hpp"
#include "CheckSum.h"
#include "uart.h"
#include "encoder_driver.h"

using namespace std;

// Assuming these are declared elsewhere, e.g., in main.c
extern TIM_HandleTypeDef htim3;
extern UART_HandleTypeDef huart1;

uint16_t FillData(const array<uint8_t, 4> &payload, PacketID packetID)
{
    if (payload.size() != 4)
    {
        ("Payload size must be 4 bytes.\r\n");
        return -1;
    }
    Packet packet;
    packet.start_packet = 0xAA55;
    packet.end_packet = 0x0D0A;
    packet.count = 1;
    packet.packetID = static_cast<uint8_t>(packetID);

    for (int i = 0; i < 4; i++)
    {
        packet.payload[i] = payload[i];
    }
    uint8_t checksumData[6];
    memcpy(checksumData, packet.payload, 4);
    checksumData[4] = packet.packetID;
    checksumData[5] = packet.count;
    packet.checksum = checksum(checksumData, 6);

    return packet.checksum;
}


uint8_t SerializePacket(const Packet packet)
{
    // Check start and end packet values
    if (packet.start_packet != 0xAA55 || packet.end_packet != 0x0D0A)
    {
        HAL_UART_Transmit(&huart1, (const uint8_t*)"Invalid start or end packet values.\r\n",36, HAL_MAX_DELAY);
        return 1; // Error code for invalid start/end bytes
    }

    // Checksum validation
    uint8_t checksumData[6];
    memcpy(checksumData, packet.payload, 4);
    checksumData[4] = packet.packetID;
    checksumData[5] = packet.count;
    uint16_t checksumresult = checksum(checksumData, 6);

    if (packet.checksum != checksumresult)
    {
        return 2; // Error code for checksum mismatch
    }

    // Process the packet based on its ID
    switch (packet.packetID)
    {
        case Motor_ID:
        {
            Motor motor;
            motor.ID = packet.payload[0];
            motor.speed = packet.payload[1];
            motor.direction = packet.payload[2];
            // Add motor control logic here
            break;
        }

        case MotorAngle_ID:
        {
            MotorAngle motorAngle;
            motorAngle.ID = packet.payload[0];
            motorAngle.angle = packet.payload[1];
            motorAngle.direction = packet.payload[2];

            // Transmit the received motor angle data over UART for debugging
            const uint8_t label_id[] = "ID: ";
            HAL_UART_Transmit(&huart1, (const uint8_t*)"Encoder Data Read:\r\n", 24, HAL_MAX_DELAY);
            
            HAL_UART_Transmit(&huart1, label_id, sizeof(label_id) - 1, HAL_MAX_DELAY);
            HAL_UART_Transmit(&huart1, &motorAngle.ID, 1, HAL_MAX_DELAY);

            HAL_UART_Transmit(&huart1, (const uint8_t*)"\r\nAngle: ", 9, HAL_MAX_DELAY);
            HAL_UART_Transmit(&huart1, &motorAngle.angle, 1, HAL_MAX_DELAY);

            HAL_UART_Transmit(&huart1, (const uint8_t*)"\r\nDirection: ", 14, HAL_MAX_DELAY);
            HAL_UART_Transmit(&huart1, &motorAngle.direction, 1, HAL_MAX_DELAY);

            HAL_UART_Transmit(&huart1, (const uint8_t*)"\r\n", 2, HAL_MAX_DELAY);

            Encoder_ReadData(&htim3, &motorAngle, 1); // Read encoder data
            break;
        }

        case CarHorn_ID:
        {
            CarHorn carHorn;
            carHorn.ID = packet.payload[0];
            carHorn.duartion = packet.payload[1];
            break;
        }

        case CarLight_ID:
        {
            CarLight carLight;
            carLight.ID = packet.payload[0];
            carLight.lightStatus = packet.payload[1];
            break;
        }

        case CarConfirmation_ID:
        {
            CarConfirmation carConfirmation;
            carConfirmation.ID = packet.payload[0];
            carConfirmation.confirmationStatus = packet.payload[1];
            carConfirmation.value = packet.payload[2];
            break;
        }

        default:
        {
            // Note: HAL_UART_Transmit does not support printf-style formatting.
            // Using a pre-defined string is the correct approach here.
            HAL_UART_Transmit(&huart1, (const uint8_t*)"Unknown packet ID\r\n", 19, HAL_MAX_DELAY);
            return 3; // Error code for unknown packet ID
        }
    }

    return 0; // Success
}
